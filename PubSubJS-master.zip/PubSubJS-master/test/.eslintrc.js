module.exports = {
	"env": {
		"commonjs": true,
		"mocha": true,
		"node": true
	}
};
